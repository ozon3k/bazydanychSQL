create trigger trigger1
  after INSERT
  on studenci
  for each row
  BEGIN

INSERT INTO studenci2 SELECT * FROM studenci WHERE id_studenta = max(id_studenta);

END;

